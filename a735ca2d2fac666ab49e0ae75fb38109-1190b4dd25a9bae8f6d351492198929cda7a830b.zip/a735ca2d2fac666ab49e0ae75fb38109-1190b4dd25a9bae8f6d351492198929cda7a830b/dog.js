module.exports = class Dog {
  constructor(name, toothStrength) {
    this.name = name;
    this.toothStrength = toothStrength;
  }
};