module.exports = class Cat {
  constructor(name, clawStrength) {
    this.name = name;
    this.clawStrength = clawStrength;
  }
};